class CfgDifficulties
{
 /* class Recruit
  {
    scoreImage = "\ca\ui\textures\deb_pecka.paa";
    badScoreImage = "\ca\ui\textures\deb_krizek.paa";
  };*/

  class Regular
  {
    scoreImage = "\ca\ui\textures\deb_pecka.paa";
    badScoreImage = "\ca\ui\textures\deb_krizek.paa";
  };

  class Veteran
  {
    scoreImage = "\ca\ui\textures\deb_hvezdicka.paa";
    badScoreImage = "\ca\ui\textures\deb_krizek.paa";
  };
/*
  class Mercenary
  {
		scoreImage = "\ca\ui\textures\deb_hvezdicka.paa";
    badScoreImage = "\ca\ui\textures\deb_krizek.paa";
	};*/
};