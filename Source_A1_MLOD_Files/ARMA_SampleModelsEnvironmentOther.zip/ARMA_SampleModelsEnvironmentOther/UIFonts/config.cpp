class CfgPatches
{
	class CAFonts
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.10;
		requiredAddons[] = {};
	};
};

#include "cfgFont.hpp"