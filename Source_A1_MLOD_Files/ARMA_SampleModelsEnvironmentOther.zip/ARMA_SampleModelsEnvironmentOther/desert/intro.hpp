class Veg_1
{
	name="";
	position[]={2713.62,2140.92};
	type="VegetationPalm";
	radiusA=50;
	radiusB=50;
};
class Veg_2
{
	name="";
	position[]={2446.09,3038.29};
	type="VegetationPalm";
	radiusA=50;
	radiusB=50;
};
class Veg_3
{
	name="";
	position[]={2940.52,2923.19};
	type="VegetationPalm";
	radiusA=50;
	radiusB=50;
};
