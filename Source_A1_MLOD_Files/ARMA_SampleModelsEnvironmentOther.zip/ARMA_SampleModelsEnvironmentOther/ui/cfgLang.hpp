class CfgLanguages
{
    class English
    {
        name =  $STR_LANG_ENGLISH; // used in UI in list of languages
    };
    class French
    {
        name = $STR_LANG_FRENCH;
    };
    class Spanish
    {
        name = $STR_LANG_SPANISH; // used in UI in list of languages
    };
    class Italian
    {
        name = $STR_LANG_ITALIAN;
    };

    class German
    {
        name = $STR_LANG_GERMAN; // used in UI in list of languages
    };
    class Czech
    {
        name = $STR_LANG_CZECH;
    };
    class Polish
    {
        name = $STR_LANG_POLISH;
    };

    class Russian
    {
        name = $STR_LANG_RUSSIAN;
    };

};