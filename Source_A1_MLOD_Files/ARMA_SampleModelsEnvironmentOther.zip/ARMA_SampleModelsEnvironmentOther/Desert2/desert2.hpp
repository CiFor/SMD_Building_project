class D2Veg_1
{
	name="";
	position[]={2075.13,2393.05};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2City
{
	name="Porto";
	position[]={2602.89,2421.03};
	type="NameCity";
	radiusA=100;
	radiusB=100;
};
class D2Veg_2
{
	name="";
	position[]={3056.87,2445.02};
	type="VegetationPalm";
	radiusA=50;
	radiusB=50;
};
class D2Veg_3
{
	name="";
	position[]={2345.8,2538.02};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2Veg_4
{
	name="";
	position[]={3179.16,2429.75};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2Veg_5
{
	name="";
	position[]={2884.51,2264.38};
	type="VegetationPalm";
	radiusA=50;
	radiusB=50;
};
class D2Veg_6
{
	name="";
	position[]={2919.3,2700.92};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2Veg_7
{
	name="";
	position[]={3140.47,2759.52};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2Veg_8
{
	name="";
	position[]={3339.87,2928.39};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2Veg_9
{
	name="";
	position[]={3031.39,2571.2};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2Veg_10
{
	name="";
	position[]={2213.08,2130.29};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
class D2Veg_11
{
	name="";
	position[]={1397.23,2295.08};
	type="VegetationPalm";
	radiusA=50;
	radiusB=50;
};
class D2Veg_12
{
	name="";
	position[]={2072.33,2213.94};
	type="VegetationPalm";
	radiusA=50;
	radiusB=50;
};
class D2Veg_13
{
	name="";
	position[]={1868.87,2278.64};
	type="VegetationBroadleaf";
	radiusA=50;
	radiusB=50;
};
