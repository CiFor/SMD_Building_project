class CfgPatches
{
	class CARocks
	{
		units[] = {};
		weapons[] = {};
		requiredVersion = 0.10;
		requiredAddons[] = {};
	};
};
