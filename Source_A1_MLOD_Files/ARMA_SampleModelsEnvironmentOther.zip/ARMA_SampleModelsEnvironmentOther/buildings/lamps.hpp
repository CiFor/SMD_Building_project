class BUILD_NAME(lampadrevo): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampadrevo;
	};
	class BUILD_NAME(lampazel): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampazel;
	};
	class BUILD_NAME(vo_seda): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\vo_seda;
	};
	class BUILD_NAME(tlampac_vo_seda): BUILD_NAME(vo_seda)
	{
		scope=protected;
		model=BuildingPath\Misc\tlampac_vo_seda;
	};
	class BUILD_NAME(vo_zlut): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\vo_zlut;
	};
	class BUILD_NAME(lampa_cut): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_cut;
	};
	class BUILD_NAME(lampa_valec): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_valec;
	};
	class BUILD_NAME(lampa_koule): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_koule;
	};
	class BUILD_NAME(lampa_sidl): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_sidl;
	};
	class BUILD_NAME(lampa_sidl_2): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_sidl_2;
	};
	class BUILD_NAME(lampa_sidl_3): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_sidl_3;
	};
	class BUILD_NAME(lampa_ind): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_ind;
	};
	class BUILD_NAME(lampa_ind_b): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_ind_b;
	};
	class BUILD_NAME(lampa_ind_zebr): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_ind_zebr;
	};
	class BUILD_NAME(lampa_vysoka) : StreetLamp
	{
		scope = protected;
		model = BuildingPath\misc\lampa_vysoka.p3d;
	};
	class BUILD_NAME(lampa_vysoka2): StreetLamp
	{
		scope=protected;
		model=BuildingPath\Misc\lampa_vysoka2;
	};
